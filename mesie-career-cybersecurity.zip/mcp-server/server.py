#!/usr/bin/env python3
"""MESIE Career MCP — Cybersecurity pillar (200 careers)."""

from __future__ import annotations

import json
import sys
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / "careers" / "catalog.json"
PILLAR = "cybersecurity"
FEED = ROOT / "deliverables" / "CAREER_FEED.jsonl"


def _load() -> List[Dict[str, Any]]:
    return json.loads(CATALOG.read_text(encoding="utf-8"))


def _reply(mid: Any, payload: Dict[str, Any]) -> None:
    out = {"jsonrpc": "2.0", "id": mid, "result": payload}
    sys.stdout.write(json.dumps(out) + "\n")
    sys.stdout.flush()


def career_list(args: Dict[str, Any]) -> Dict[str, Any]:
    careers = _load()
    team, stage = args.get("team"), args.get("stage")
    if team:
        careers = [c for c in careers if c.get("team") == team]
    if stage:
        careers = [c for c in careers if c.get("stage") == stage]
    limit = int(args.get("limit", 50))
    slim = [{"id": c["id"], "title": c["title"], "team": c["team"], "stage": c["stage"]} for c in careers[:limit]]
    return {"ok": True, "pillar": PILLAR, "count": len(careers), "careers": slim}


def career_get(args: Dict[str, Any]) -> Dict[str, Any]:
    cid = str(args.get("career_id", ""))
    for c in _load():
        if c["id"] == cid:
            return {"ok": True, "career": c}
    return {"ok": False, "error": f"not found: {cid}"}


def career_search(args: Dict[str, Any]) -> Dict[str, Any]:
    q = str(args.get("query", "")).lower()
    hits = [{"id": c["id"], "title": c["title"]} for c in _load() if q in f"{c['title']} {c['team']}".lower()]
    return {"ok": True, "hits": hits[:30]}


def career_invoke(args: Dict[str, Any]) -> Dict[str, Any]:
    r = career_get(args)
    if not r.get("ok"):
        return r
    c = r["career"]
    FEED.parent.mkdir(parents=True, exist_ok=True)
    rec = {"career_id": c["id"], "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "envelope_id": str(uuid.uuid4())}
    with FEED.open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec) + "\n")
    return {"ok": True, "career_id": c["id"], "pulse": {"mission": c["mission"], "stage": c["stage"]}, "envelope": rec}


def career_triple_route(args: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "ok": True,
        "protocol": "MESIE-CAREER-TRIPLE-PROTOCOL/1.0",
        "route": {
            "P1_loom": "vault career memory",
            "P2_mcp": "this server",
            "P3_bridge": "http://127.0.0.1:8767 → :8750",
        },
        "career_id": args.get("career_id"),
    }


TOOLS = {
    "career_list": career_list,
    "career_get": career_get,
    "career_search": career_search,
    "career_invoke": career_invoke,
    "career_triple_route": career_triple_route,
}


def main() -> None:
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        mid, method = msg.get("id"), msg.get("method")
        if method == "initialize":
            _reply(mid, {"protocolVersion": "2024-11-05", "capabilities": {"tools": {}}})
        elif method == "tools/list":
            _reply(mid, {"tools": [{"name": k, "description": k, "inputSchema": {"type": "object"}} for k in TOOLS]})
        elif method == "tools/call":
            params = msg.get("params") or {}
            name = params.get("name", "")
            args = params.get("arguments") or {}
            fn = TOOLS.get(name)
            result = fn(args) if fn else {"ok": False, "error": f"unknown: {name}"}
            _reply(mid, {"content": [{"type": "text", "text": json.dumps(result, indent=2)}]})


if __name__ == "__main__":
    main()
